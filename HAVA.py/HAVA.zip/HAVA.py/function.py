#We will have two function. Non input and input. when we say time, date etc it is a command that is input but if google search hava will have to input value for the output

import datetime
from Speak import speak

def Time():
    time = datetime.datetime.now().strftime("%H : %M")
    speak(time)

def Date():
    date = datetime.date.today()
    speak(date)

def Day():
    day = datetime.datetime.now().strftime("%A")
    speak(day)

def NonInputExecution(query):
    query = str(query)

    if "time" in query:
        Time()
    
    elif "date" in query:
        Date()

    elif "day" in query:
        Day()